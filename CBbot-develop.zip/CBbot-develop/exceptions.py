class EmailDoesNotExists(Exception):
    pass


class InvalidAddress(Exception):
    pass
